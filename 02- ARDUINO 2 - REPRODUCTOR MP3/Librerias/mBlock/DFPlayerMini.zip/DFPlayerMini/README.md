# DFPlayerMini - Un mini reproductor MP3 para Arduino

DFPlayerMini - Un mini reproductor MP3 para Arduino. DFPlayerMini es una extensión para [mBlock](http://www.mblock.cc) que sirve para controlar con Arduino módulos reproductores MP3 DFPlayer Mini. Esta extensión emplea la libreria [DFRobotDFPlayerMini](https://github.com/DFRobot/DFRobotDFPlayerMini) para [Arduino](http://arduino.cc), habiéndose adaptado para poder ser utilizada con mBlock.

Descargar
----------
La version mas actualizada se encuentra en el github de [MatrizLed-mBlock](https://github.com/miqueas1988/DFPlayerMini)

Instalación
----------
La instalación se realiza desde mBlock. Ir a "Administrar Extensiones" y buscar por "MatrizLed".

Uso
----------
En mBlock, al añadir los nuevos bloques a la ventana de programa, aparecerán comentadas las líneas de código en el visualizador de código Arduino, explicando el uso de cada bloque.
